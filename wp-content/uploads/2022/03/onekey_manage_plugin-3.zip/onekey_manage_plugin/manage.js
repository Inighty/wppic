$(document).ready(function () {
    const csrfToken = $("meta[name='csrfToken']").attr("content");
    var main = document.getElementById('divMain2');
    var table = document.getElementsByClassName('plugin-list')[0];

    var div = document.createElement('div');
    var input1 = document.createElement('input');
    input1.type = 'button';
    input1.value = '全选';
    input1.setAttribute("id", "checkall");
    div.appendChild(input1);

    var input2 = document.createElement('input');
    input2.type = 'button';
    input2.value = '取消全部';
    input2.setAttribute("id", "removeall");
    div.appendChild(input2);

    var input3 = document.createElement('input');
    input3.type = 'button';
    input3.value = '反选';
    input3.setAttribute("id", "reverse");
    div.appendChild(input3);

    var input4 = document.createElement('input');
    input4.type = 'button';
    input4.value = '选中停止';
    input4.setAttribute("id", "stop");
    div.appendChild(input4);

    var input5 = document.createElement('input');
    input5.type = 'button';
    input5.value = '选中开启';
    input5.setAttribute("id", "start");
    div.appendChild(input5);

    var input6 = document.createElement('input');
    input6.type = 'button';
    input6.value = '全部开启';
    input6.setAttribute("id", "allstart");
    div.appendChild(input6);

    var input7 = document.createElement('input');
    input7.type = 'button';
    input7.value = '全部停止';
    input7.setAttribute("id", "allstop");
    div.appendChild(input7);

    main.insertBefore(div, table);

// 全选
    $("#checkall").click(function () {
        $(".love").each(function () {
            this.checked = true;
        });
    });
// 取消全部
    $("#removeall").click(function () {
        $(".love").each(function () {
            this.checked = false;
        });
    });
// 反选
    $("#reverse").click(function () {
        $(".love").each(function () {
            this.checked = this.checked !== true;
        })
    });

    $("#start").click(function () {
        var ids = [];
        $(".love").each(function () {
            if ($(this).is(':checked')) {
                ids.push($(this).attr('id').replace('ok-', ''));
            }
        });
        if (ids.length === 0) {
            alert('请选择要开启的插件');
        } else {
            ids = ids.join(',');
            if (confirm("确定开启所选插件？")) {
                $.ajax({
                    type: 'post',
                    async: true,
                    url: bloghost + "zb_users/plugin/onekey_manage_plugin/manage_plugin.php?act=start&csrfToken=" + csrfToken + "&" + new Date(),
                    data: {
                        pluginids: ids
                    },
                    dataType: 'json',
                    success: function (data) {
                        location.href = window.location.href;
                    },
                    error: function (data) {
                        location.href = window.location.href;
                    }
                });
            }
        }
    });

    $("#stop").click(function () {
        var ids = [];
        $(".love").each(function () {
            if ($(this).is(':checked')) {
                ids.push($(this).attr('id').replace('ok-', ''));
            }
        });
        if (ids.length === 0) {
            alert('请选择要停止的插件');
        } else {
            ids = ids.join(',');
            if (confirm("确定停止所选插件？")) {
                $.ajax({
                    type: 'post',
                    async: true,
                    url: bloghost + "zb_users/plugin/onekey_manage_plugin/manage_plugin.php?act=stop&csrfToken=" + csrfToken + "&" + new Date(),
                    data: {
                        pluginids: ids
                    },
                    dataType: 'json',
                    success: function (data) {
                        location.href = window.location.href;
                    },
                    error: function (data) {
                        location.href = window.location.href;
                    }
                });
            }
        }
    });

    $("#allstart").click(function () {
        if (confirm("确定开启所有插件？")) {
            $.ajax({
                type: 'post',
                async: true,
                url: bloghost + "zb_users/plugin/onekey_manage_plugin/manage_plugin.php?act=allstart&csrfToken=" + csrfToken + "&" + new Date(),
                data: {},
                dataType: 'json',
                success: function (data) {
                    location.href = window.location.href;
                },
                error: function (data) {
                    location.href = window.location.href;
                }
            });
        }
    });

    $("#allstop").click(function () {
        if (confirm("确定停止所有插件？")) {
            $.ajax({
                type: 'post',
                async: true,
                url: bloghost + "zb_users/plugin/onekey_manage_plugin/manage_plugin.php?act=allstop&csrfToken=" + csrfToken + "&" + new Date(),
                data: {},
                dataType: 'json',
                success: function (data) {
                    location.href = window.location.href;
                },
                error: function (data) {
                    location.href = window.location.href;
                }
            });
        }
    });

});