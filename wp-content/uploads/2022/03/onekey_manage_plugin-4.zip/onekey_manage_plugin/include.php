<?php
#注册插件
RegisterPlugin("onekey_manage_plugin", "ActivePlugin_onekey_manage_plugin");


function ActivePlugin_onekey_manage_plugin()
{
    Add_Filter_Plugin('Filter_Plugin_Admin_PluginMng_SubMenu', 'onekey_manage_plugin_js');
    Add_Filter_Plugin('Filter_Plugin_Admin_End', 'onekey_manage_plugin_checkbox');
}

function onekey_manage_plugin_js()
{
    global $zbp;
    echo '<script src="' . $zbp->host . 'zb_users/plugin/onekey_manage_plugin/manage.js" type="text/javascript"></script>';
}

function onekey_manage_plugin_checkbox()
{
    global $zbp;
    echo '<script src="' . $zbp->host . 'zb_users/plugin/onekey_manage_plugin/checkbox.js" type="text/javascript"></script>';
}

function InstallPlugin_onekey_manage_plugin()
{
}

function UninstallPlugin_onekey_manage_plugin()
{
}