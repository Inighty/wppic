<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';
$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('onekey_manage_plugin')) {
    $zbp->ShowError(48);
    die();
}
if (function_exists('CheckIsRefererValid')) {
    CheckIsRefererValid();
}

$act = GetVars("act", "GET");

$plugin = null;
try {
    if ($act == "stop") {
        $pluginid = GetVars("pluginids", "POST");
        $ids = trim($pluginid);
        $pluginids = explode(',', $ids);
        foreach ($pluginids as $item)
            DisablePlugin($item);
    } elseif ($act == "start") {
        $pluginid = GetVars("pluginids", "POST");
        $ids = trim($pluginid);
        $pluginids = explode(',', $ids);
        foreach ($pluginids as $item)
            EnablePlugin($item);
    } elseif ($act == "allstart") {
        global $zbp;
        foreach ($zbp->LoadPlugins() as $app) {
            if (!$zbp->CheckPlugin($app->id)) {
                $plugin = $app;
                EnablePlugin($app->id);
            }
        }
    } elseif ($act == "allstop") {
        global $zbp;
        foreach ($zbp->LoadPlugins() as $app) {
            if ($app->id == 'onekey_manage_plugin') {
                continue;
            }
            if ($zbp->CheckPlugin($app->id)) {
                $plugin = $app;
                DisablePlugin($app->id);
            }
        }
    }

    $zbp->BuildModule();
    $zbp->SaveCache();
    $zbp->SetHint('good', '操作成功');
} catch (Exception $e) {
    $errmsg = '';
    if ($plugin != null) {
        $errmsg .= $plugin->name . ' 插件处理异常：';
    }
    $errmsg .= $e->getMessage();
    $zbp->SetHint('bad', $errmsg);
}