<?php
require '../../../zb_system/function/c_system_base.php';
require '../../../zb_system/function/c_system_admin.php';
$zbp->Load();
$action = 'root';
if (!$zbp->CheckRights($action)) {
    $zbp->ShowError(6);
    die();
}
if (!$zbp->CheckPlugin('onekey_manage_plugin')) {
    $zbp->ShowError(48);
    die();
}

if (count($_POST) > 0) {
    CheckIsRefererValid();
}

$blogtitle = '批量停止插件';
require $blogpath . 'zb_system/admin/admin_header.php';
require $blogpath . 'zb_system/admin/admin_top.php';
?>
    <div style="font-size: 14px;color: #6b6868">
        <p style="padding: 10px">插件已经处于激活状态，插件管理界面会新增批量管理功能按钮</p>
    </div>
<?php
require $blogpath . 'zb_system/admin/admin_footer.php';
RunTime();
?>