<?php
#注册插件
RegisterPlugin("onekey_manage_plugin", "ActivePlugin_onekey_manage_plugin");


function ActivePlugin_onekey_manage_plugin()
{
    Add_Filter_Plugin('Filter_Plugin_Admin_Footer', 'onekey_manage_plugin_InsertScript');
}

function onekey_manage_plugin_InsertScript()
{
    global $zbp;
    $act = GetVars("act", "GET");
    if ($act === "PluginMng"){
        echo '<script src="' . $zbp->host . 'zb_users/plugin/onekey_manage_plugin/checkbox.js" type="text/javascript"></script>';
        echo '<script src="' . $zbp->host . 'zb_users/plugin/onekey_manage_plugin/manage.js" type="text/javascript"></script>';
    }
}

function InstallPlugin_onekey_manage_plugin()
{
}

function UninstallPlugin_onekey_manage_plugin()
{
}