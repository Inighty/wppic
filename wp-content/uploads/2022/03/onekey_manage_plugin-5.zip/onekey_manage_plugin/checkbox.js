$(document).ready(function () {
    var table = document.getElementsByClassName('tableFull')[0];
    tr = table.getElementsByTagName('tr');
    for (i = 0; i < tr.length; i++) {
        var td = document.createElement('td');

        td.style.width = '2%';
        var input = document.createElement('INPUT');
        input.type = 'checkbox';
        if (i === 0) {
            input.setAttribute('id', 'selectall');
            input.onclick = function () {
                var all = document.getElementById('selectall');
                var loves = document.getElementsByClassName('onekey_manage_love');
                if (!all.checked) {
                    for (var j = 0; j < loves.length; j++) {
                        loves[j].checked = false;
                    }
                } else {
                    for (var j = 0; j < loves.length; j++) {
                        loves[j].checked = true;
                    }
                }
            }
        } else {
            var myString = tr[i].innerHTML;
            var myRegexp = new RegExp('name=(.*?)&', "g");
            match = myRegexp.exec(myString);
            if (match != null) {
                input.setAttribute("id", "ok-" + match[1]);
            }
            input.classList.add('onekey_manage_love');
        }
        td.appendChild(input);

        tr[i].insertBefore(td, tr[i].childNodes[0]);
    }
});